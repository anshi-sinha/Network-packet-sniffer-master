# Network-Packet-Sniffer
Network packet sniffer or simply packet sniffer is a packet analyzer software that monitors all network traffic. The proposed project is implemented in Java programming language, and using this application admin of the system can capture network packet and analyze data received/sent from/to the network.
